import time, math
from pymycobot.myagv import MyAgv
import rospy
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion



class Patrol:
    def __init__(self, MA):
        self.MA = MA

        self.v_forward = 0.18      
        self.kp_yaw    = 0.8       
        self.max_wz    = 0.8       

    def _yaw(self):

        return math.radians(self.MA.get_imu_yaw_deg())

    def _wrap(self, a):
        return (a + math.pi) % (2*math.pi) - math.pi

    def go_straight_holding_heading(self, duration_sec):
        target_yaw = self._yaw()
        t0 = time.time()
        while time.time() - t0 < duration_sec:
            yaw = self._yaw()
            err = self._wrap(target_yaw - yaw)
            wz  = max(-self.max_wz, min(self.kp_yaw * err, self.max_wz))  # P����
            # ��ī��: vx, vy, wz ���°� ������ (vx=self.v_forward, vy=0, wz=wz)
            # ������ API�� ��/�� �ӵ��� ��ȯ�ؼ� �ֱ�
            self.MA.vel_ctrl(vx=self.v_forward, vy=0.0, wz=wz)
            time.sleep(0.02)  # 50Hz ����
        self.MA.stop()

MA = MyAgv('/dev/ttyAMA2', 115200)
pt = Patrol(MA)


while True:
    pt.go_straight_holding_heading(2.5)
    time.sleep(0.5)

    pt.v_forward = -0.18
    pt.go_straight_holding_heading(2.5)
    pt.v_forward = +0.18
    time.sleep(0.5)
