import cv2
import numpy as np
from pymycobot.myagv import MyAgv
import threading, time

agv = MyAgv("/dev/ttyAMA2", 115200)

# ====== ROI / ���� Ʃ�� ======
CENTER_LINE_THICK = 6

# ��� ���� ROI (�ȼ� ����)
ROI_NEAR_H = 70          # �ٴڿ� ���� ����� �� ����(px)
ROI_FAR_H  = 70          # �� ���� ���� �� ����(px)
ROI_GAP    = 40          # near�� far ���� ����(px)
# ��: [�ٴ�..�ٴ�+70] = near, [�ٴ�+70+���� .. +70+����+70] = far

DEAD_BAND  = 40          # �߾� ���� ��� ����(px) - ���� ROI������ ���� �ٿ��� ��
MIN_AREA   = 600         # �ּ� ������ ����

# ����ġ(near�� �� ū ����)
W_NEAR = 0.7
W_FAR  = 0.3

# ====== �̵� �޽�/�ӵ� (�ʹ� ������ ������ ���� ����) ======
BASE_SPEED = 12
CORRECTION_FACTOR = 1
L_SPEED_FWD = BASE_SPEED + CORRECTION_FACTOR
R_SPEED_FWD = BASE_SPEED

PULSE_SEC_FWD  = 0.05
PULSE_SEC_TURN = 0.05
COOLDOWN_SEC   = 0.10
TURN_GAIN_BASE = 0.55  # �⺻ ȸ�� ����(���� ����)

_last_cmd_time = 0.0

def _has(name): return hasattr(agv, name)

def _safe_stop():
    try:
        if _has("stop"): agv.stop()
        elif _has("stop_move"): agv.stop_move()
    except: pass

def _set_wheels(l, r):
    if _has("set_wheels_speed"):
        agv.set_wheels_speed(int(l), int(r))
        return True
    return False

def _forward_pulse():
    dur = PULSE_SEC_FWD
    if not _set_wheels(L_SPEED_FWD, R_SPEED_FWD):
        if _has("go_ahead"): agv.go_ahead(BASE_SPEED)
        elif _has("forward"): agv.forward(BASE_SPEED)
    time.sleep(dur); _safe_stop()

def _turn_pulse(sign, gain):  # sign: -1(left), +1(right)
    dur = PULSE_SEC_TURN
    lw =  int(L_SPEED_FWD * gain * (1 if sign>0 else -1))   # ��ȸ��: L+, R-
    rw = -int(R_SPEED_FWD * gain * (1 if sign>0 else -1))
    if not _set_wheels(lw, rw):
        if sign > 0 and _has("clockwise_rotation"): agv.clockwise_rotation(5)
        elif sign < 0 and _has("counterclockwise_rotation"): agv.counterclockwise_rotation(5)
    time.sleep(dur); _safe_stop()

def _cooldown_ok():
    global _last_cmd_time
    now = time.time()
    if now - _last_cmd_time >= COOLDOWN_SEC:
        _last_cmd_time = now
        return True
    return False

def _red_mask(bgr_roi):
    hsv = cv2.cvtColor(bgr_roi, cv2.COLOR_BGR2HSV)
    lower1 = np.array([0,   100, 100], np.uint8)
    upper1 = np.array([10,  255, 255], np.uint8)
    lower2 = np.array([170, 100, 100], np.uint8)
    upper2 = np.array([180, 255, 255], np.uint8)
    m = cv2.bitwise_or(cv2.inRange(hsv, lower1, upper1), cv2.inRange(hsv, lower2, upper2))

    return cv2.GaussianBlur(m, (5,5), 0)

def _black_mask(bgr_roi):
    hsv = cv2.cvtColor(bgr_roi, cv2.COLOR_BGR2HSV)
 
    lower = np.array([20, 100, 100], np.uint8)
    upper = np.array([40, 255, 255], np.uint8)
    mask = cv2.inRange(hsv, lower, upper)
    
    return cv2.GaussianBlur(mask, (5, 5), 0)

def _centroid_x(mask):
    cnts,_ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts: return None, None
    c = max(cnts, key=cv2.contourArea)
    if cv2.contourArea(c) < MIN_AREA: return None, None
    M = cv2.moments(c)
    if M["m00"] == 0: return None, None
    cx = int(M["m10"]/M["m00"])
    return cx, c

def process_frame(frame):
    h, w, _ = frame.shape
    cx_center = w // 2

    # === near ROI (�ٴڿ� ���� ����� ���� ��) ===
    y2_near = h                   # �ٴ�
    y1_near = max(0, h - ROI_NEAR_H)
    roi_near = frame[y1_near:y2_near, :]
    mask_near = _red_mask(roi_near)
    cx_near, c_near = _centroid_x(mask_near)

    # === far ROI (�� ���� ��) ===
    y2_far = max(0, y1_near - ROI_GAP)
    y1_far = max(0, y2_far - ROI_FAR_H)
    roi_far = frame[y1_far:y2_far, :]
    mask_far = _red_mask(roi_far)
    cx_far, c_far = _centroid_x(mask_far)

    # �ð�ȭ
    cv2.line(frame, (cx_center, 0), (cx_center, h), (0,255,0), CENTER_LINE_THICK)
    cv2.rectangle(frame, (0, y1_near), (w, y2_near), (0,255,0), 1)
    cv2.rectangle(frame, (0, y1_far),  (w, y2_far),  (255,255,0), 1)
    if c_near is not None: cv2.drawContours(frame[y1_near:y2_near], [c_near], -1, (0,255,0), 2)
    if c_far  is not None: cv2.drawContours(frame[y1_far:y2_far],  [c_far],  -1, (0,255,0), 2)

    # ���� ��� (�������� +, ������ -)
    e_near = (cx_near - cx_center) if cx_near is not None else None
    e_far  = (cx_far  - cx_center) if cx_far  is not None else None

    # ���� ����
    if e_near is None and e_far is None:
        return "NONE", frame, 0.0

    if e_near is None: e = W_FAR  * e_far
    elif e_far is None: e = W_NEAR * e_near
    else: e = W_NEAR*e_near + W_FAR*e_far

    # ���� ũ�⿡ ���� ȸ�� ���� ���� (�������� ���ϰ�, Ŭ���� ���ϰ�)
    norm = max(1.0, w*0.5)                 # �뷫�� ����ȭ
    gain = TURN_GAIN_BASE * min(1.0, abs(e)/norm*4.0)

    if e < -DEAD_BAND:
        return "LEFT", frame, gain
    elif e >  DEAD_BAND:
        return "RIGHT", frame, gain
    else:
        return "CENTER", frame, 0.0

def camera_loop():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Camera open failed"); return
    try:
        while True:
            ok, frame = cap.read()
            if not ok: print("Camera error"); break

            action, vis, gain = process_frame(frame)

            if _cooldown_ok():
                if action == "LEFT":
                    threading.Thread(target=_turn_pulse, args=(-1, gain), daemon=True).start()
                elif action == "RIGHT":
                    threading.Thread(target=_turn_pulse, args=(+1, gain), daemon=True).start()
                elif action == "CENTER":
                    threading.Thread(target=_forward_pulse, daemon=True).start()
                # NONE�̸� �ƹ��͵� �� ��

            cv2.imshow("Frame", vis)
            if cv2.waitKey(1) & 0xFF == 27:  # ESC
                break
    finally:
        _safe_stop()
        cap.release()
        cv2.destroyAllWindows()
        agv.stop()

if __name__ == "__main__":
    camera_loop()
