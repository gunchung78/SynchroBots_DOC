# view_usb_cam.py
import cv2

cam_index = 0  # /dev/video0
cap = cv2.VideoCapture(cam_index, cv2.CAP_V4L2) 

#
cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG')) 
cap.set(cv2.CAP_PROP_FRAME_WIDTH,  1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
cap.set(cv2.CAP_PROP_FPS, 30)

if not cap.isOpened():
    raise SystemExit(" /dev/video0")

while True:
    ok, frame = cap.read()
    if not ok:
        print("test")
        break
    cv2.imshow("myAGV Camera", frame)
    if cv2.waitKey(1) & 0xFF == 27:  # ESC to quit
        break