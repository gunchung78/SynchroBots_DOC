from pymycobot.myagv import MyAgv
import time
MA = MyAgv('/dev/ttyAMA2',115200)

MA.go_ahead(30)
time.sleep(2)

MA.stop()
time.sleep(1)


MA.retreat(60)
time.sleep(2)

# MA.pan_left(30)
# time.sleep(2)

# MA.pan_right(30)
# time.sleep(2)

MA.stop()